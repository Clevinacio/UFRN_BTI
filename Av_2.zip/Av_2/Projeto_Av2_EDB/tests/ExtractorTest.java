import org.junit.Test;

import static org.junit.Assert.*;

public class ExtractorTest {

    @Test
    public void makeCodificationTable() {
    }

    @Test
    public void makeBitSet() {
    }

    @Test
    public void convertBitSetToString() {
    }
}